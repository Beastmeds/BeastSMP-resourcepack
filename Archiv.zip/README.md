# BeastSMP Custom Menu Pack

Ein Resource Pack im Beast-Look (dunkelrot/schwarz) für's Pause-Menü — angelehnt an den LegitMC-Screenshot.

## Was drin ist
- **Panorama-Hintergrund** (`assets/minecraft/textures/gui/title/background/panorama_0.png` bis `panorama_5.png`): dunkles rot/schwarzes Gradient mit leichten "Grunge"-Streifen und Vignette statt der Standard-Minecraft-Welt.
- **Lang-Files** (`de_de.json` + `en_us.json`): Menü-Texte umbenannt, u.a.
  - `menu.returnToGame` → "Auf **BeastSMP** weiterspielen" (pink/magenta via `§d`)
  - `menu.disconnect` → "**Bis Bald!**" (rot via `§c`)
- **pack.png**: eigenes Icon (dunkelrot/schwarz mit "B"-Pixel-Logo) fürs Pack-Auswahlmenü.

## Installation
1. Ordner `beastsmp_pack` in einen `.zip` umwandeln (bzw. die ZIP-Datei direkt nutzen, die ich dir gebe).
2. In `.minecraft/resourcepacks/` legen.
3. Im Spiel unter Options → Resource Packs aktivieren.
4. Für den Server: als Server-Resource-Pack hosten (z.B. über `server.properties` → `resource-pack=` + `resource-pack-sha1=`), dann bekommen alle Spieler es automatisch beim Join vorgeschlagen.

## pack_format anpassen
Ich hab `pack_format: 34` gesetzt (passt zu 1.21.x) plus einen großzügigen `supported_formats`-Bereich, damit die "Pack ist evtl. inkompatibel"-Warnung meist nicht auftaucht. Falls du eine andere MC-Version fährst, sag mir welche, dann passe ich die Zahl exakt an.

## Eigene Extra-Buttons (Spinne, Skin-Icon, Warndreieck, Liste im Screenshot)
Die kannst du mit reinem Resource Pack **nicht** nachbauen — das sind zusätzliche klickbare Buttons, die per Mod/Mixin ins Pause-Menü injected wurden (z.B. eigener Discord-Button, Report-Button, Server-Stats). Das wäre ein separates NeoForge/Fabric-Mod-Projekt. Sag Bescheid, wenn du das als nächstes willst — dann bauen wir dir ein Mixin, das den `PauseScreen` erweitert.

## Eigenes Panorama-Bild statt Gradient
Willst du statt dem generierten Gradient ein echtes Bild von deinem BeastSMP-Spawn/Build als Hintergrund? Schick mir einen Screenshot deiner Map, dann bastel ich dir daraus die 6 Panorama-Kacheln (oder du machst In-Game Screenshots aus 6 Blickrichtungen an einem Spawn-Punkt).

## Custom Font (der "gamige" Pixel-Font im Screenshot)
Das ist meist ein eigener Bitmap-Font (`assets/minecraft/font/default.json` + PNG). Das hab ich hier bewusst weggelassen, weil es ein bisschen Bastelei braucht (Font-Sheet zeichnen). Sag Bescheid, dann ergänze ich das auch noch.
